# Requisitos Funcionales

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23  
> **Marco:** IEEE 830 | **Priorización:** MoSCoW

Los requisitos funcionales de la sección 1.1 del SRS (v1.0), derivados directamente de recolección de información (entrevistas, observaciones, encuestas, revisión documental).

---

## RF01 — Registro de Venta (POS Básico)

**Prioridad:** Must Have

**Descripción:** El sistema registra una venta seleccionando productos del catálogo; calcula subtotal, impuestos y total en tiempo real. Registra el método de pago (efectivo o digital) y, si es efectivo, calcula y muestra el cambio automáticamente. Al confirmar la venta genera el tiquete de forma automática (depende de RF06) y descuenta stock (depende de RF03). Toda la operación funciona en modo offline (depende de RNF02).

**Criterios de Aceptación:**
- Una venta con hasta 15 productos distintos se registra en ≤3 segundos en el hardware mínimo (Android 8.0, 2 GB RAM)
- El stock de cada producto vendido se descuenta al confirmar, sin intervención adicional del operario
- Si no hay internet, la venta se guarda localmente y se sincroniza al recuperar la conexión

---

## RF02 — Catálogo de Productos

**Prioridad:** Must Have

**Descripción:** Gestiona un catálogo de hasta 90 productos con los atributos: nombre, precio de venta, categoría, stock actual y stock mínimo. Solo el Administrador puede crear, editar o eliminar productos. Los empleados tienen acceso de solo lectura. El sistema valida que el nombre no esté duplicado y que el precio sea un número positivo. Un precio actualizado se refleja en todos los puntos de venta activos en menos de 5 segundos.

**Criterios de Aceptación:**
- El Administrador puede crear, editar o eliminar un producto en máximo 3 clics (depende de RNF06)
- El sistema rechaza nombres duplicados mostrando un mensaje descriptivo en línea
- Los empleados no ven los controles de editar ni eliminar en la vista de inventario

---

## RF03 — Control de Inventario y Alertas de Stock

**Prioridad:** Should Have

**Descripción:** Descuenta automáticamente el stock del producto al registrar cada venta (acoplado a RF01). Cuando el stock llega al umbral mínimo configurado por el Administrador, genera una alerta visible en pantalla. La alerta persiste hasta que el Administrador la confirme o el stock sea repuesto. El sistema bloquea la venta de un producto con stock en cero e informa al operario.

**Criterios de Aceptación:**
- Al completar una venta, el stock se reduce en la cantidad exacta vendida, sin errores
- La alerta de stock mínimo aparece sin que el Administrador necesite consultar el inventario manualmente
- No es posible registrar una venta de un producto con stock = 0

---

## RF04 — Corte de Caja Diario

**Prioridad:** Should Have

**Descripción:** Genera al cierre de cada jornada un resumen de ventas: total efectivo, total digital, número de transacciones y desglose por empleado. El Administrador ingresa el efectivo físico en caja; el sistema calcula y muestra la diferencia con semáforo (verde = $0, amarillo < $5 000, rojo ≥ $5 000). Permite registrar una observación textual para justificar diferencias. Al confirmar el cierre, activa el respaldo automático (depende de RNF08). Solo el Administrador accede a este módulo (depende de RNF04).

**Criterios de Aceptación:**
- El resumen del día es coherente con el historial de transacciones registradas
- La diferencia entre efectivo del sistema y físico se calcula correctamente
- El backup se ejecuta automáticamente al confirmar el cierre, sin acción extra del usuario
- El reporte se puede exportar a PDF desde la misma pantalla

---

## RF05 — Gestión de Crédito / Fiado

**Prioridad:** Should Have

**Descripción:** Registra créditos con los campos: nombre del cliente, monto inicial, fecha de otorgamiento, abonos y saldo pendiente. Emite alerta al Administrador para deudas con más de 30 días sin abono. Solo el Administrador accede a este módulo.

**Criterios de Aceptación:**
- El saldo se actualiza en tiempo real tras cada abono ingresado
- Los clientes con más de 30 días sin abono aparecen marcados con alerta en el listado
- El historial de abonos de cada cliente es consultable en cualquier momento

---

## RF06 — Generación de Tiquete de Venta

**Prioridad:** Should Have

**Descripción:** Al completar cada venta genera automáticamente un tiquete con: fecha, hora, lista de productos con precios, total, método de pago y nombre del cajero. El tiquete se puede imprimir o enviar como PDF por WhatsApp.

**Criterios de Aceptación:**
- El tiquete se genera en ≤3 segundos tras confirmar la venta, sin acción extra del operario
- Contiene todos los campos requeridos sin datos faltantes
- La opción de envío por WhatsApp está disponible directamente desde la pantalla de cierre de venta

---

## RF07 — Historial de Ventas con Filtros

**Prioridad:** Could Have

**Descripción:** El Administrador puede consultar el historial filtrado por: rango de fechas, empleado y producto específico. Los empleados solo ven las ventas que ellos mismos registraron en el turno en curso.

**Criterios de Aceptación:**
- Los filtros devuelven resultados coherentes con las transacciones almacenadas
- Un empleado no puede ver las ventas de otro ni los totales consolidados del negocio

---

**Relacionado:** [non-functional.md](./non-functional.md) | [user-stories.md](./user-stories.md) | [traceability-matrix.md](./traceability-matrix.md)
