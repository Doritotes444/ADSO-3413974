# Matriz de Trazabilidad

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

Relación entre requisitos, historias de usuario, evidencia de recolección y dependencias.

---

## Requisitos Funcionales → Evidencia

| RF | Descripción | Origen | Prioridad | Relacionado |
|----|----|---------|-----------|----------|
| **RF01** | Registro de Venta (POS) | Entrevista P1, Ficha obs. pasos 2-3, Encuesta E8 (5 clientes) | Must Have | HU-01, RNF02, RNF03 |
| **RF02** | Catálogo de Productos | Entrevista P2, D04 (8 precios incorrectos), Empleado Diego Morales, Clientes Rosa Vargas/Hernán Ospina/Felipe Salcedo | Must Have | HU-02, RNF06 |
| **RF03** | Control de Inventario y Alertas | Entrevista P3, D05 (pedidos por memoria), D01 (sin clasificación), Cita Carlos: "No sé cuándo se va a acabar..." | Should Have | HU-03, RF01 (acoplado) |
| **RF04** | Corte de Caja Diario | Entrevista P6, D06 (sin desglose) | Should Have | HU-04, RNF08, RNF04 |
| **RF05** | Gestión de Crédito/Fiado | Entrevista P8, D02 (12 clientes, $336K COP, sin abonos) | Should Have | HU-07 |
| **RF06** | Generación de Tiquete | Encuesta E5 (Carmen Acosta, Patricia Molina, Pedro Jiménez) | Should Have | HU-06, RF01 (disparado por) |
| **RF07** | Historial de Ventas con Filtros | Entrevista P6, D01 (sin clasificación por empleado/producto) | Could Have | HU-02 (auditoría), RNF04 |

---

## Requisitos No Funcionales → Evidencia

| RNF | Descripción | Origen | Prioridad | RF Relacionados |
|------|-----------|--------|-----------|----------|
| **RNF01** | Interfaz Intuitiva, ≤2h | Entrevista P10, Perfil usuario (resistencia tecnológica) | Must Have | RF01, RF02, RF06 |
| **RNF02** | Modo Offline | Entrevista P11, Internet inestable doméstico | Must Have | RF01, RF02, RF03 |
| **RNF03** | ≤3 seg por transacción | Ficha observación (suma 120 seg = 44 % del total) | Should Have | RF01 |
| **RNF04** | Control de Acceso por Roles | Entrevista P9, "Solo yo debo ver totales" | Should Have | RF04, RF05, RF07 |
| **RNF05** | Hardware de Bajo Costo | Entrevista P12, Presupuesto limitado | Must Have | Todos los RF |
| **RNF06** | Actualización sin Asistencia Técnica | D04 (8 precios desactualizados) | Should Have | RF02 |
| **RNF08** | Respaldo Automático Diario | D01–D06 (riesgo total de pérdida) | Should Have | RF04 |

---

## Historias de Usuario → Requisitos Funcionales

| HU | RF Primario | RNF Primario | Otros |
|----|----------|----------|-------|
| **HU-01** | RF01 | RNF02, RNF03, RNF01 | Descuento de stock (RF03) |
| **HU-02** | RF02 | RNF06, RNF01 | Propagación <5 seg (sección 6.2) |
| **HU-03** | RF03 | RNF01 | Acoplado a RF01 |
| **HU-04** | RF04 | RNF04, RNF08 | Exportación PDF, semáforo |
| **HU-05** | RF01 | RNF02 | Sincronización automática |
| **HU-06** | RF06 | RNF01 | PDF por WhatsApp |
| **HU-07** | RF05 | RNF04 | Alerta >30 días |
| **HU-08** | Todos | RNF01 | Aprendizaje en 1 jornada |

---

## Dependencias Entre Requisitos

```
RF01 (Venta)
  ├─ depende de RF03 (descuento stock)
  ├─ depende de RF06 (genera tiquete)
  └─ requiere RNF02 (offline) y RNF03 (≤3 seg)

RF02 (Catálogo)
  ├─ requiere RNF06 (sin asistencia técnica)
  └─ depende de RNF04 (solo Admin edita)

RF03 (Inventario)
  ├─ acoplado a RF01
  ├─ dispara alerta (CF3 en sección 3)
  └─ requiere RNF01 (interfaz intuitiva)

RF04 (Corte)
  ├─ depende de RNF08 (respaldo automático)
  ├─ requiere RNF04 (solo Admin accede)
  └─ genera observación (semáforo rojo >$5K COP)

RF05 (Crédito)
  ├─ requiere RNF04 (solo Admin)
  └─ dispara alerta por morosidad (>30 días)

RF06 (Tiquete)
  ├─ disparado por RF01
  ├─ requiere RNF01 (sin pasos extras)
  └─ requiere disponibilidad de impresora O WhatsApp

RF07 (Historial)
  ├─ requiere RNF04 (empleados no ven otros)
  └─ depende de RF01 (datos de transacciones)

RNF02 (Offline)
  └─ cubre RF01, RF02, RF03 (sección 7.3)

RNF08 (Backup)
  └─ disparado por RF04
```

---

## Riesgos y Supuestos Documentados

| Código | Descripción | Origen | Mitigación |
|--------|------------|--------|------------|
| **RIESGO-1** | Pérdida total de registros (incendio/robo) | D01–D06, RNF08 | Respaldo automático en Google Drive |
| **RIESGO-2** | Internet inestable | Entrevista P11, RNF02 | Funcionamiento offline completo |
| **RIESGO-3** | Resistencia tecnológica | Entrevista P10, RNF01 | Inducción máx 2 horas, interfaz intuitiva |
| **RIESGO-4** | Precios desactualizados | D04, RNF06 | Actualización sin asistencia técnica en ≤3 clics |
| **SUP-1** | Hardware Android 8.0+ existente | Entrevista P12 | Compatibilidad explícita en RNF05 |
| **SUP-2** | Carlos es único Admin permanente | Entrevista P9 | Rol único en RNF04; no hay escalabilidad para múltiples admins en MVP |

---

**Documentos relacionados:** [functional.md](./functional.md) | [non-functional.md](./non-functional.md) | [user-stories.md](./user-stories.md)
