# Requisitos

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Centraliza requisitos funcionales, no funcionales, historias de usuario y trazabilidad.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [functional.md](./functional.md) | Requisitos funcionales (RF01–RF07): POS, Catálogo, Inventario, Corte, Crédito, Tiquete, Historial | 🟢 |
| [non-functional.md](./non-functional.md) | Requisitos no funcionales (RNF01–RNF06, RNF08): Interfaz, Offline, Rendimiento, Roles, Hardware, Actualización, Backup | 🟢 |
| [user-stories.md](./user-stories.md) | Historias de usuario (HU-01–HU-08) con criterios de aceptación | 🟢 |
| [traceability-matrix.md](./traceability-matrix.md) | Trazabilidad RF/RNF ↔ HU ↔ Evidencia; dependencias; riesgos y supuestos | 🟢 |
