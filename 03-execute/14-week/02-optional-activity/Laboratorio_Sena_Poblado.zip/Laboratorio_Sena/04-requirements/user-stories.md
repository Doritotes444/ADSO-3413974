# Historias de Usuario

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

Las historias de usuario se derivan directamente de los hallazgos de la recolección de información (sección 1.5 del SRS). Cada una representa una necesidad real de los actores identificados.

---

## HU-01 — Registrar una venta sin calculadora

**Como** operario del supermercado (Carlos Ruiz, Martha Suárez, Julián Torres o Diego Morales)

**Quiero** seleccionar los productos que trae el cliente desde el catálogo digital y que el sistema calcule el total automáticamente

**Para que** pueda cobrar sin necesidad de sumar con calculadora y reducir el tiempo de atención por transacción

**Criterios de aceptación:**
- Puedo buscar un producto por nombre y agregarlo a la venta con un solo tap
- El total se actualiza en tiempo real al agregar o quitar productos
- El sistema calcula el cambio cuando el pago es en efectivo
- La venta queda registrada aunque no haya internet al momento del cobro

---

## HU-02 — Mantener los precios siempre actualizados

**Como** Administrador (Carlos Ruiz)

**Quiero** poder actualizar el precio de cualquier producto en el catálogo en menos de 3 clics, desde la tablet o el computador

**Para que** todos los empleados vean el precio correcto al momento de cobrar, sin depender de una lista de precios escrita

**Criterios de aceptación:**
- El precio actualizado se refleja en el POS de los empleados en menos de 5 segundos
- El sistema no me deja guardar un precio vacío ni con letras
- Solo yo (Administrador) puedo cambiar precios; los empleados solo los consultan

---

## HU-03 — Saber cuándo se agota un producto antes de que ocurra

**Como** Administrador (Carlos Ruiz)

**Quiero** configurar un stock mínimo por producto y recibir una alerta cuando se llegue a ese límite

**Para que** pueda hacer el pedido al proveedor a tiempo, sin descubrir el agotamiento cuando el cliente ya lo pide

**Criterios de aceptación:**
- El sistema me muestra la alerta sin que yo tenga que revisar el inventario manualmente
- No puedo vender un producto que ya tiene stock en cero
- La alerta se mantiene visible hasta que yo la confirme o reponga el stock

---

## HU-04 — Cuadrar la caja al final del día sin hacer cuentas a mano

**Como** Administrador (Carlos Ruiz)

**Quiero** ver un resumen automático de las ventas del día, ingresar el efectivo físico en caja y que el sistema calcule la diferencia

**Para que** pueda cerrar la jornada con un corte de caja trazable y con respaldo digital, reemplazando el documento D06

**Criterios de aceptación:**
- El resumen me muestra: total efectivo, total digital, número de transacciones y desglose por empleado
- El sistema me indica en rojo cuando la diferencia supera $5.000 COP
- Al confirmar el cierre, se genera automáticamente una copia de seguridad
- Puedo exportar el reporte del día en PDF

---

## HU-05 — Trabajar con el sistema aunque se caiga el internet

**Como** operario del supermercado

**Quiero** poder registrar ventas y consultar el inventario aunque no haya conexión a internet

**Para que** la operación del negocio no se detenga cuando el servicio de internet del local falle

**Criterios de aceptación:**
- El sistema me muestra un indicador claro cuando estoy trabajando sin internet
- Todas las ventas registradas en modo offline quedan guardadas y se sincronizan solas al volver la conexión
- No pierdo ningún dato si el internet se cae en medio de un registro

---

## HU-06 — Darle tiquete al cliente sin impresora

**Como** operario del supermercado

**Quiero** poder enviarle el tiquete de la venta al cliente por WhatsApp en formato PDF

**Para que** el cliente tenga comprobante de su compra aunque no haya impresora disponible en el mostrador

**Criterios de aceptación:**
- El tiquete se genera automáticamente al finalizar la venta, sin pasos adicionales
- Tengo la opción de imprimir o enviar por WhatsApp directamente desde la pantalla de cierre
- El tiquete incluye: fecha, hora, productos con precios, total, método de pago y mi nombre como cajero

---

## HU-07 — Controlar el fiado sin perder plata

**Como** Administrador (Carlos Ruiz)

**Quiero** registrar los créditos de mis clientes de confianza con sus abonos y saldo pendiente, y recibir una alerta cuando llevan más de 30 días sin abonar

**Para que** pueda llevar la cartera de $336 000 COP (12 clientes activos) sin depender del cuaderno de fiado D02, que no tiene columna de abonos ni saldo actualizado

**Criterios de aceptación:**
- Puedo registrar un abono y el saldo se actualiza automáticamente
- Los clientes con más de 30 días sin abonar aparecen marcados con alerta
- Puedo ver el historial completo de abonos de cada cliente

---

## HU-08 — Aprender a usar el sistema en una jornada

**Como** Administrador (Carlos Ruiz)

**Quiero** poder aprender a operar el sistema completo en una sesión de inducción de máximo 2 horas

**Para que** no depender de soporte técnico externo para el uso diario y poder capacitar a mis empleados yo mismo

**Criterios de aceptación:**
- Las acciones más frecuentes (registrar venta, buscar producto, ver precio) se alcanzan en máximo 2 taps desde la pantalla principal
- Todos los textos están en español colombiano, sin tecnicismos en inglés
- El flujo de una venta completa es completable sin leer manual

---

**Matriz de trazabilidad:** [traceability-matrix.md](./traceability-matrix.md)
