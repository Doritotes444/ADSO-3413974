# Requisitos No Funcionales

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23  
> **Marco:** ISO/IEC 25010 (Modelo de Calidad)

---

## RNF01 — Interfaz Intuitiva — Inducción máxima 2 horas

**Prioridad:** Must Have

Un operario sin experiencia técnica previa debe poder completar una venta completa (registro, cobro y tiquete) tras una inducción de máximo 2 horas. Todos los textos, etiquetas y mensajes están en español colombiano, sin tecnicismos en inglés visibles para el usuario. Las acciones más frecuentes (registrar venta, buscar producto, ver precio) deben ser accesibles en máximo 2 taps o clics desde la pantalla principal.

**Fuente:** Entrevista P10 — "Que sea sencillo, que yo pueda aprender en un día." Resistencia tecnológica moderada documentada en perfil de usuario.

---

## RNF02 — Funcionamiento en Modo Offline

**Prioridad:** Must Have

El sistema opera con plena funcionalidad de ventas e inventario (RF01, RF02, RF03) sin conexión a internet. Al recuperar la conexión, los registros pendientes se sincronizan automáticamente con el servidor en menos de 5 minutos. Un indicador visual muestra en todo momento el estado de la conexión (en línea / modo offline).

**Fuente:** Entrevista P11 — "A veces se cae, pero en general funciona." Internet básico domiciliario con disponibilidad variable.

---

## RNF03 — Tiempo de Respuesta ≤3 segundos por Venta

**Prioridad:** Should Have

El registro de una venta con hasta 15 productos no debe tardar más de 3 segundos desde la confirmación hasta la generación del tiquete. Restricción medida en el hardware mínimo: Android 8.0 con 2 GB de RAM.

**Meta post-MVP:** Reducir el tiempo por transacción de 382 segundos (proceso manual actual) a ≤145 segundos — reducción del 62 %.

**Fuente:** Ficha de observación — paso 3 (suma manual con calculadora): 120 seg = 44 % del tiempo total por transacción.

---

## RNF04 — Control de Acceso por Roles

**Prioridad:** Should Have

El sistema implementa dos roles: Administrador (Carlos Ruiz) con acceso total, y Empleado (Martha, Julián, Diego) con acceso solo a registro de ventas e inventario en modo consulta. Un intento de acceso a módulos restringidos (reportes, edición de precios, créditos) queda bloqueado y registrado.

**Fuente:** Entrevista P9 — "Solo yo debo ver las ventas totales."

---

## RNF05 — Compatibilidad con Hardware de Bajo Costo

**Prioridad:** Must Have

Funciona en tablet Android 8.0+ con mínimo 2 GB de RAM y en computador Windows 10 con mínimo 2 GB de RAM. No requiere hardware especializado (lectores de barras físicos, cajas registradoras, pinpads).

**Fuente:** Entrevista P12 — presupuesto limitado del negocio.

---

## RNF06 — Actualización del Catálogo sin Asistencia Técnica

**Prioridad:** Should Have

El Administrador puede agregar, editar o eliminar productos sin ayuda de personal técnico externo. Cada operación sobre el catálogo (crear, editar, eliminar) debe completarse en máximo 3 clics.

**Fuente:** D04 — 8 precios desactualizados porque no hay un mecanismo sencillo de actualización.

---

## RNF08 — Respaldo Automático Diario de Datos

**Prioridad:** Should Have

Al confirmar el corte de caja (RF04), el sistema genera automáticamente un backup de la base de datos. El respaldo se almacena localmente; si hay conexión, se sube a Google Drive.

**Fuente:** D01–D06 — todos los registros del negocio son físicos, sin ningún respaldo digital. Riesgo total de pérdida por incendio, robo o deterioro.

---

**Relación:** [functional.md](./functional.md) | [user-stories.md](./user-stories.md)
