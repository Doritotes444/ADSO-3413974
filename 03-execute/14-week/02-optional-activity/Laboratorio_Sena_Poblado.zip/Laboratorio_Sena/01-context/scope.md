# Alcance y Limitaciones

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## MVP — En Alcance

| Módulo | Descripción |
|--------|-------------|
| **POS Básico** | Registro de venta en tablet Android: selección de productos, cálculo automático, pago (efectivo/digital), generación de tiquete |
| **Catálogo de Productos** | Gestión en Windows administrativo: crear, editar, eliminar hasta 90 productos (nombre, precio, categoría, stock) |
| **Inventario** | Descuento automático de stock al vender, alertas de stock mínimo, bloqueo de venta con stock = 0 |
| **Corte de Caja Diario** | Resumen de ventas, desglose por empleado, validación de efectivo físico vs. sistema, respaldo automático |
| **Gestión de Crédito** | Registro de clientes, monto inicial, abonos, alertas por mora (>30 días sin abono) |
| **Funcionalidad Offline** | Operación completa sin internet; sincronización automática al recuperar conexión |

## Exclusiones Explícitas

- ❌ **Notificaciones push a clientes finales** — El tiquete se envía por WhatsApp, pero no hay canal automático hacia el cliente
- ❌ **Integración con pasarelas de pago** (Nequi, Daviplata, datáfono) — El pago digital se registra manualmente en el sistema
- ❌ **Soporte para iOS/macOS** — Solo Android (tablet) y Windows (oficina)
- ❌ **Integración directa con proveedores** — El pedido de reposición es manual (alerta al admin, él llama)
- ❌ **Análisis predictivo o machine learning** — Solo reportes de ventas básicos
- ❌ **Portal web para clientes** — Sin autoservicio de consulta de deuda

## Supuestos Técnicos

- Internet doméstico inestable pero presente para sincronización
- Hardware existente suficiente (Android 8.0+, 2 GB RAM; Windows 10, 2 GB RAM)
- Impresora térmica opcional (si no existe, tiquete por WhatsApp en PDF)
- Google Drive disponible para respaldo automático

## Restricciones de Negocio

- **Presupuesto:** Costo único de desarrollo, sin licencias anuales
- **Aprendizaje:** Inducción máxima de 2 horas para operarios sin experiencia técnica
- **Dependencia de roles:** Carlos Ruiz como único Administrador; empleados sin acceso a reportes ni precios consolidados

---

**Más contexto:** [overview.md](./overview.md) | [glossary.md](./glossary.md)
