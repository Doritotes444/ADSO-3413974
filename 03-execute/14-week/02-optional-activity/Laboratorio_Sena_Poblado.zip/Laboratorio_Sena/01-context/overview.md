# Contexto — Supermercado La Esquina

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23  
> **Autor:** Doria (SENA ADSO #3413974) | **Equipo:** Análisis y Desarrollo de Software

## Descripción General

Este repositorio contiene la documentación técnica del **Sistema de Punto de Venta e Inventario (MVP)** para **Supermercado La Esquina**, un pequeño comercio en Colombia que requiere modernizar su gestión de ventas y control de inventario.

### Cliente

**Supermercado La Esquina** — pequeño negocio minorista dirigido por **Carlos Ruiz**, operado por cuatro personas (Martha Suárez, Julián Torres, Diego Morales) con presupuesto limitado y resistencia tecnológica moderada.

### Módulos en Alcance

- **Inventario y Punto de Venta (POS)**
- Control de stock con alertas automáticas
- Corte de caja diario
- Gestión de crédito a clientes de confianza (fiado)

### Marco Normativo

- **IEEE 830** — Estructura de especificación de requisitos de software
- **ISO/IEC 25010** — Modelo de calidad de producto de software
- **MoSCoW** — Priorización de requisitos (Must/Should/Could Have)
- **SENA Competencia 220501046** — Contexto institucional de formación

### Problema Raíz

El negocio operaba sin sistema: precios desactualizados, cálculo manual de ventas (120 segundos por transacción con calculadora), cartera de crédito ($336.000 COP) sin columna de abonos, y riesgo total de pérdida de registros (documentos físicos sin respaldo digital).

### Visión Técnica

Entregar un sistema integrado (tablet Android + Windows 10) que reduce el tiempo de transacción de ~6 minutos a ≤3 segundos, elimina el riesgo de pérdida de datos y permite trabajo offline sin depender de conectividad doméstica inestable.

---

**Documentación relacionada:** [scope.md](./scope.md) | [glossary.md](./glossary.md)
