# Glosario Técnico y de Dominio

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Términos de Negocio (La Esquina)

| Término | Definición |
|---------|-----------|
| **Fiado / Crédito** | Venta registrada sin cobro inmediato al cliente de confianza; genera deuda con plazo abierto |
| **Abono** | Pago parcial a cuenta de un crédito pendiente |
| **Saldo pendiente** | Monto original del crédito menos la suma de abonos recibidos |
| **Corte de caja** | Cierre de jornada: reconciliación de ventas del sistema vs. efectivo físico en caja |
| **Tiquete** | Comprobante de venta: lista de productos, precios, total, método de pago, nombre del cajero |
| **Stock mínimo** | Cantidad umbral de producto; al alcanzarse, genera alerta |
| **Cartera** | Suma total de créditos pendientes (en La Esquina: $336.000 COP de 12 clientes) |

## Siglas Técnicas

| Sigla | Significado | Contexto |
|-------|-------------|---------|
| **SRS** | Especificación de Requisitos de Software | Documento base (IEEE 830) |
| **MVP** | Producto Viable Mínimo | Primera versión a producción |
| **RF** | Requisito Funcional | Capacidad: "El sistema registra una venta" |
| **RNF** | Requisito No Funcional | Atributo de calidad: "En ≤3 segundos" |
| **HU** | Historia de Usuario | Narrativa: "Como [rol], quiero [acción], para [beneficio]" |
| **MoSCoW** | Método de priorización | Must Have (crítico), Should Have (importante), Could Have (deseable) |
| **POS** | Punto de Venta | Terminal de caja donde se registran transacciones |
| **JWT** | JSON Web Token | Token sin estado para autenticación cliente-servidor |
| **FCM** | Firebase Cloud Messaging | Servicio de notificaciones push de Google |
| **SQLite** | Base de datos embebida | Persistencia offline en la tablet |
| **HTTPS/REST** | Protocolo de comunicación | Transferencia segura de datos con API estilo REST |

## Roles

| Rol | Nombre en La Esquina | Permisos Clave |
|-----|---------------------|----------------|
| **Administrador** | Carlos Ruiz | Acceso total: catálogo, precios, reportes, corte, créditos |
| **Empleado** | Martha, Julián, Diego | Registro de ventas y consulta de inventario (solo lectura) |

---

**Consultar:** [overview.md](./overview.md) | [scope.md](./scope.md)
