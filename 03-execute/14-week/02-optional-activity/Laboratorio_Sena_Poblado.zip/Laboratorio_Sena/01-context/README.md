# Contexto

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe el contexto institucional, alcance y vocabulario del proyecto **Sistema de Punto de Venta e Inventario para Supermercado La Esquina**.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Contexto del negocio, problema raíz, visión técnica | 🟢 |
| [scope.md](./scope.md) | Alcance de MVP, exclusiones explícitas, supuestos técnicos | 🟢 |
| [glossary.md](./glossary.md) | Términos de dominio (fiado, abono, corte de caja) y siglas técnicas | 🟢 |
