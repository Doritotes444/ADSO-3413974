# Calidad

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Define prácticas de pruebas, revisión de código y criterios de calidad.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [testing-strategy.md](./testing-strategy.md) | Estrategia de pruebas funcionales, rendimiento, offline, seguridad, UAT basada en CA de RF/HU | 🟢 |
| [code-review.md](./code-review.md) | Criterios y flujo para revisiones de código | 🔴 |
