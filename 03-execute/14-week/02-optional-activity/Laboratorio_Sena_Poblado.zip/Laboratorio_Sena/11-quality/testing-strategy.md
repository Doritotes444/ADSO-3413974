# Estrategia de Pruebas

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Pruebas Funcionales (Criterios de Aceptación)

Cada RF y HU debe cumplir sus criterios de aceptación documentados en [../04-requirements/functional.md](../04-requirements/functional.md) y [../04-requirements/user-stories.md](../04-requirements/user-stories.md).

**Ejemplos de casos de prueba:**

| Requisito | Caso de Prueba | Resultado Esperado |
|-----------|----------------|------------------|
| **RF01** | Registrar venta con 5 productos | Venta en ≤3 seg; stock descuento; tiquete generado |
| **RF02** | Crear producto con precio $800 | Producto visible en POS en <5 seg |
| **RF02** | Crear producto con nombre duplicado | Error: "nombre ya existe" |
| **RF03** | Stock actual = stock mínimo | Alerta visible sin consulta manual |
| **RF04** | Diferencia caja = $5.500 | Semáforo ROJO; puede confirmar con observación |
| **RF05** | Cliente sin abono >30 días | Marcado con alerta en listado |
| **RF06** | Finalizar venta → generar tiquete | Tiquete disponible para imprimir/WhatsApp en ≤3 seg |

---

## Pruebas de Rendimiento

**Restricción:** Hardware mínimo (Android 8.0, 2 GB RAM)

| Métrica | Requisito | Aceptable | Rechazo |
|---------|-----------|-----------|---------|
| Tiempo transacción (RF01) | ≤3 seg | ≤3 seg | >3 seg ❌ |
| Propagación de precio (RF02) | <5 seg | <5 seg | ≥5 seg ❌ |
| Sincronización offline (RNF02) | <5 min | <5 min | ≥5 min ❌ |

**Herramientas:** Chrome DevTools (emulador), Xcode Instruments, Android Profiler

---

## Pruebas de Compatibilidad

| Plataforma | Versión | Estado |
|-----------|---------|--------|
| **Android** | 8.0 (API 26) | MVP mínimo |
| **Android** | 10, 11, 12+ | Deseable |
| **Windows** | 10 | MVP mínimo |
| **Windows** | 11 | Deseable |

---

## Pruebas de Offline (RNF02)

| Escenario | Pasos | Resultado Esperado |
|-----------|-------|------------------|
| **Venta sin internet** | 1. Desconectar WiFi 2. Registrar venta | Venta guardada localmente; indica modo offline |
| **Sincronización** | 1. Reconectar WiFi 2. Esperar <5 min | Venta sincronizada; ya no en cola pendiente |
| **Conflicto de datos** | 1. Venta offline, cambio de precio online, sincronizar | Servidor decide (last-write-wins); admin notificado si hay anomalía |

---

## Pruebas de Seguridad

| Aspecto | Caso | Resultado Esperado |
|--------|------|------------------|
| **Autenticación** | Empleado intenta acceder sin token | 401 Unauthorized |
| **Autorización** | Empleado intenta editar precio | 403 Forbidden; no se muestra control en interfaz |
| **JWT expirado** | Token con `exp` < ahora | Pedir login de nuevo |
| **Acceso no autorizado registrado** | Intentos fallidos de acceso | Auditoría interna registra evento |

---

## Pruebas de Aceptación del Usuario (UAT)

**Participantes:** Carlos Ruiz (Admin), Martha (Empleado)

| Escenario | Validación |
|-----------|-----------|
| **Registrar una venta completa** | ¿Es más rápido que con calculadora? ¿Menos errores? |
| **Cambiar un precio** | ¿Puede hacerlo sin ayuda técnica en <2 clics? |
| **Ver stock mínimo** | ¿Entiende la alerta sin capacitación adicional? |
| **Cuadrar la caja** | ¿El semáforo le indica si hay discrepancia? |
| **Trabajar sin internet** | ¿El sistema funciona normalmente offline? |

---

**Más detalles:** [../04-requirements/functional.md](../04-requirements/functional.md)
