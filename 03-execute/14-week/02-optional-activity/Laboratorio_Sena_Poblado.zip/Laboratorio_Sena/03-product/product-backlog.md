# Backlog de Producto

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## MVP — Priorización por MoSCoW

### Must Have (Críticos)

| ID | Descripción | Criterio de Aceptación |
|----|-------------|------------------------|
| **RF01** | Registro de Venta (POS Básico) | Venta con hasta 15 productos en ≤3 seg; descuento de stock sin intervención; funciona offline |
| **RF02** | Catálogo de Productos | Gestión de hasta 90 productos; Administrador puede crear/editar/eliminar en ≤3 clics; precio actualizado visible en <5 seg |
| **RNF01** | Interfaz Intuitiva | Operario sin experiencia completa venta tras 2 horas de inducción; textos en español; acciones clave en ≤2 taps |
| **RNF02** | Funcionamiento Offline | Operación completa sin internet; sincronización <5 min al recuperar conexión; indicador visual de estado |
| **RNF05** | Hardware de Bajo Costo | Compatible con Android 8.0+ / 2 GB RAM y Windows 10 / 2 GB RAM; sin hardware especializado |

### Should Have (Importantes)

| ID | Descripción | Criterio de Aceptación |
|----|-------------|------------------------|
| **RF03** | Control de Inventario y Alertas | Descuento automático; alerta al stock mínimo; bloqueo de venta con stock = 0 |
| **RF04** | Corte de Caja Diario | Resumen automático; diferencia con semáforo; respaldo automático; exportación a PDF |
| **RF05** | Gestión de Crédito/Fiado | Registro de cliente, monto, abonos; alerta >30 días sin abono |
| **RF06** | Generación de Tiquete | Auto-generación en ≤3 seg; impresión O envío por WhatsApp en PDF |
| **RNF03** | Tiempo de Respuesta ≤3 seg | Medido en hardware mínimo (Android 8.0, 2 GB RAM) |
| **RNF04** | Control de Acceso por Roles | Dos roles: Administrador (acceso total) y Empleado (solo ventas + inventario lectura) |
| **RNF06** | Actualización de Catálogo sin Asistencia | Cada operación (crear/editar/eliminar) en ≤3 clics sin intervención técnica |
| **RNF08** | Respaldo Automático Diario | Backup al confirmar cierre; almacenamiento en Google Drive o local |

### Could Have (Deseables)

| ID | Descripción | Criterio de Aceptación |
|----|-------------|------------------------|
| **RF07** | Historial de Ventas con Filtros | Filtro por rango de fechas, empleado, producto específico; coherencia con transacciones almacenadas |

---

## Métricas de Éxito por Funcionalidad

| Funcionalidad | Línea Base | Meta |
|---------------|-----------|------|
| Tiempo transacción | 382 seg (manual) | ≤145 seg (sistema) — mejora 62 % |
| Precios desactualizados | 8 de 90 (9 %) | 0 de 90 (0 %) |
| Cartera sin registrar | 100 % (cuaderno manual) | 0 % (todas registradas en sistema) |
| Riesgo de pérdida de datos | Alto (solo físico) | Bajo (backup automático) |

---

**Más detalles:** [04-requirements/functional.md](../04-requirements/functional.md) | [04-requirements/non-functional.md](../04-requirements/non-functional.md)
