# Visión de Producto

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Propuesta de Valor

Reemplazar la gestión manual de ventas, inventario y crédito en Supermercado La Esquina con un **sistema integrado móvil + escritorio** que:

1. **Reduce el tiempo de transacción** de 382 segundos (proceso manual con calculadora) a ≤3 segundos
2. **Elimina riesgo de pérdida de datos** (registros físicos sin respaldo) con respaldo automático en Google Drive
3. **Autoriza trabajo offline** sin depender de internet doméstico inestable
4. **Capacita a operarios sin experiencia técnica** mediante interfaz intuitiva con inducción de 2 horas máximo

## Objetivos de Producto (Post-MVP)

| Objetivo | Métrica | Línea base | Meta |
|----------|---------|-----------|------|
| Velocidad de transacción | Segundos por venta | 382 seg (manual) | ≤145 seg (sistema, mejora 62 %) |
| Precisión de precios | % de productos actualizados | 91 % (8 de 90 desactualizados) | 100 % |
| Trazabilidad de cartera | Créditos sin abonos documentados | 0 % (cuaderno sin columna) | 100 % |
| Uptime operativo | Horas sin servicio por mes | N/A | <4 horas (99.7 %) |

## Público Objetivo

| Persona | Rol | Motivación |
|---------|-----|-----------|
| **Carlos Ruiz** | Dueño/Administrador | Control total sin dependencia técnica |
| **Martha, Julián, Diego** | Operarios/Cajeros | Trabajo más rápido, menos estrés de cálculo |
| **Clientes de La Esquina** | Consumidores finales | Transacciones rápidas, comprobantes digitales |

## Restricciones de Diseño

- **Hardware existente:** Android 8.0+, 2 GB RAM (tablet); Windows 10, 2 GB RAM
- **Sin presupuesto recurrente:** Costo único de desarrollo, sin suscripciones
- **Resistencia tecnológica:** Usuarios no técnicos; máximo 2 horas de inducción
- **Internet inestable:** Sistema operativo sin conexión permanente

## Éxito en Producción

El MVP es exitoso si:
- ✅ Una transacción completa (seleccionar productos → cobrar → generar tiquete) toma ≤3 segundos
- ✅ Carlos puede cambiar precios sin ayuda técnica en <2 clics
- ✅ Cero pérdida de ventas registradas (offline + backup)
- ✅ Martha/Julián/Diego registran una venta sin errores tras 1 hora de capacitación

---

**Roadmap:** [roadmap.md](./roadmap.md) | **Backlog:** [product-backlog.md](./product-backlog.md)
