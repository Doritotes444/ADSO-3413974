# Producto

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta la intención del producto, visión y backlog funcional de alto nivel.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [vision.md](./vision.md) | Propuesta de valor, objetivos de producto, público objetivo | 🟢 |
| [product-backlog.md](./product-backlog.md) | Backlog priorizado por MoSCoW (Must/Should/Could Have) | 🟢 |
