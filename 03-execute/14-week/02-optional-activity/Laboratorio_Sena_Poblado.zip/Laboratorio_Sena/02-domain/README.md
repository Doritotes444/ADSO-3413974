# Dominio

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Define el modelo de dominio de negocio, entidades, reglas y eventos del sistema.

> **Diferencia con `06-data`:** esta sección describe el dominio en términos de negocio (entidades, invariantes, reglas). Los detalles de implementación en BD van en [`06-data/`](../06-data/).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [entities-and-rules.md](./entities-and-rules.md) | Entidades principales (Producto, Venta, Crédito, etc.) e invariantes de negocio | 🟢 |
| [domain-events.md](./domain-events.md) | Eventos de dominio (VentaConfirmada, StockMínimoAlcanzado, CierreCajaConfirmado) | 🟢 |
