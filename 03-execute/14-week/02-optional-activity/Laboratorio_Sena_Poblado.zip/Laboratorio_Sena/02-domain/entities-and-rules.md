# Entidades y Reglas de Negocio

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Entidades Principales

### Producto
- **Atributos:** nombre, precio de venta, categoría, stock actual, stock mínimo
- **Invariantes:**
  - Nombre no puede ser duplicado dentro del catálogo
  - Precio debe ser número positivo > 0
  - Stock actual ≥ 0
  - Stock mínimo ≥ 0
- **Restricción de acceso:** Solo Administrador puede crear/editar/eliminar; Empleados consultan en modo lectura

### Categoría
- **Atributos:** nombre, descripción
- **Invariantes:** Nombre único
- **Nota:** Permite clasificar productos para filtrado en interfaz

### Venta
- **Atributos:** ID único, fecha, hora, empleado, total, métodos de pago (efectivo/digital), estado (confirmada/anulada)
- **Invariantes:**
  - Total ≥ 0
  - Fecha y hora registradas automáticamente por el sistema
  - Venta confirmada dispara descuento de stock de sus ItemVenta
- **Evento:** Al confirmar → genera Tiquete y sincroniza con servidor (o encola si offline)

### ItemVenta
- **Atributos:** ID, venta (FK), producto (FK), cantidad, precio unitario, subtotal
- **Invariantes:**
  - Cantidad > 0
  - Precio unitario ≥ 0
  - Subtotal = cantidad × precio unitario
  - No permitir ItemVenta de producto con stock = 0

### Empleado
- **Atributos:** ID, nombre, rol (Administrador / Empleado), estado (activo/inactivo)
- **Invariantes:**
  - Nombre único
  - Solo Administrador puede cambiar roles
- **Nota:** En fase actual, Carlos Ruiz es único administrador

### Crédito
- **Atributos:** ID, cliente (nombre), monto inicial, fecha de otorgamiento, saldo pendiente, estado (activo/cerrado)
- **Invariantes:**
  - Monto inicial > 0
  - Saldo pendiente ≤ monto inicial
  - Saldo pendiente decrece con cada Abono
- **Evento:** Cuando saldo pendiente = 0 → marcar estado = cerrado

### Abono
- **Atributos:** ID, crédito (FK), monto, fecha, observación (opcional)
- **Invariantes:**
  - Monto > 0
  - Monto ≤ saldo pendiente actual del crédito
  - Fecha registrada automáticamente
- **Evento:** Al registrar abono → actualizar saldo pendiente del crédito
- **Alerta:** Si crédito sin abono por >30 días → marcar como vencido

### CierreCaja
- **Atributos:** ID, fecha, efectivo registrado (del sistema), efectivo físico (ingresado por admin), diferencia, desglose por empleado, observación, estado (abierto/cerrado)
- **Invariantes:**
  - Diferencia = efectivo físico − efectivo registrado
  - |diferencia| ≥ $5.000 COP → semáforo rojo (alerta)
- **Evento:** Al confirmar cierre → dispara respaldo automático y sincronización

### Tiquete
- **Atributos:** ID, venta (FK), lista de ItemVenta con precios, total, método de pago, nombre del cajero, timestamp
- **Generación:** Automática al confirmar venta; sin intervención adicional del operario
- **Formatos:** Impresión térmica O envío por WhatsApp en PDF

---

## Reglas Transversales

| Regla | Descripción |
|-------|-------------|
| **Descuento automático de stock** | Al confirmar Venta, reducir stock actual de cada Producto en la cantidad de ItemVenta correspondiente |
| **Alerta de stock mínimo** | Cuando stock actual ≤ stock mínimo → mostrar notificación persistente en pantalla del Administrador |
| **Bloqueo de venta en stock cero** | Rechazar cualquier intento de agregar ItemVenta para Producto con stock actual = 0 |
| **Validación de rol en acceso** | Antes de mostrar módulos (reportes, créditos, edición de precios) → validar rol en token JWT |
| **Sincronización offline-to-online** | Registros pendientes en SQLite → sincronizar al servidor en <5 minutos al recuperar conexión |
| **Respaldo automático diario** | Al confirmar CierreCaja → generar backup de BD y subirlo a Google Drive (o almacenar localmente si no hay conexión) |

---

**Relacionado:** [domain-events.md](./domain-events.md)
