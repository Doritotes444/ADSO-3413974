# Eventos de Dominio

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Eventos Principales

### 1. VentaConfirmada
**Cuándo ocurre:** Usuario presiona "Finalizar Venta" en el POS; sistema valida y persistel a Venta.

**Consecuencias:**
- Descontar stock de cada Producto involucrado (RF03)
- Generar Tiquete automáticamente (RF06)
- Si offline, encolar sincronización; si online, enviar al servidor inmediatamente
- Resetear carrito para la siguiente transacción

**Datos:** ID de venta, lista de ItemVenta, empleado, timestamp, método de pago

---

### 2. StockMínimoAlcanzado
**Cuándo ocurre:** Stock actual de un Producto llega al umbral mínimo configurado.

**Consecuencias:**
- Generar notificación persistente en pantalla del Administrador (RF03)
- Registrar evento para historial de alertas
- Si app en segundo plano → enviar push vía Firebase Cloud Messaging (FCM)

**Datos:** ID de producto, nombre, stock actual, stock mínimo

---

### 3. CierreCajaConfirmado
**Cuándo ocurre:** Administrador ingresa efectivo físico y confirma el cierre de jornada.

**Consecuencias:**
- Validar diferencia (semáforo rojo/amarillo/verde) (RF04)
- Generar resumen de ventas del día
- Dispara respaldo automático → backup de BD → Google Drive (RNF08)
- Permitir exportación del reporte a PDF
- Registrar en historial de cierres

**Datos:** Fecha, efectivo registrado, efectivo físico, diferencia, desglose por empleado, observación

---

### 4. CréditoVencido (>30 días sin abono)
**Cuándo ocurre:** Sistema detecta que Crédito tiene >30 días desde el último Abono.

**Consecuencias:**
- Marcar Crédito con alerta visual en listado (RF05)
- La próxima vez que Administrador acceda al módulo de créditos, verá cliente marcado
- No se envía notificación push automática, pero sí aparece en pantalla al navegar

**Datos:** ID de crédito, cliente, saldo pendiente, fecha último abono, días vencidos

---

### 5. ConexiónRecuperada
**Cuándo ocurre:** Dispositivo pasa de sin conexión a con conexión detectada.

**Consecuencias:**
- Sistema activa sincronización en segundo plano de registros pendientes (Venta, Abono, cambios de catálogo)
- Plazo máximo: 5 minutos (RNF02)
- Indicador visual de modo offline desaparece
- Usuario no necesita hacer nada manualmente

**Datos:** Timestamp de reconexión, lista de operaciones pendientes sincronizadas

---

### 6. DiferenciaCajaAlta (≥$5.000 COP)
**Cuándo ocurre:** En pantalla de cierre, la diferencia entre efectivo del sistema y físico es ≥ $5.000 COP.

**Consecuencias:**
- Semáforo en pantalla pasa a rojo (RF04)
- Sistema muestra alerta antes de permitir confirmar cierre
- Administrador puede registrar observación textual para justificar (ej: "se perdió efectivo", "cliente pagó antes de registrar venta")
- Cierre aún se confirma, pero queda documentada la anomalía

**Datos:** Diferencia en COP, timestamp, observación registrada

---

## Eventos Operativos (SIN notificación pero registrados)

| Evento | Cuándo | Destino |
|--------|--------|---------|
| **AccesoNoAutorizado** | Usuario intenta abrir módulo sin permiso de rol | Auditoría (bloqueo silencioso) |
| **CatálogoActualizado** | Administrador cambia precio/nombre/stock de Producto | Propagación a <5 seg a todos los POS (RNF02) |
| **AbonoRegistrado** | Administrador registra abono a Crédito | Reducción inmediata de saldo pendiente |
| **ProductoEliminado** | Administrador elimina Producto del catálogo | No más permitido en nuevas ventas; historial conserva referencias |

---

**Diagrama sugerido:** Generar diagrama de actividad (`08-uml/diagrams/source/venta-activity.wsd`) que muestre la secuencia VentaConfirmada → DescontarStock → GenerarTiquete → Sincronizar
