# Operaciones

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe cómo operar, monitorear, responder incidentes y recuperar el sistema.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [observability.md](./observability.md) | Alertas (stock mínimo, crédito vencido, diferencia caja); auditoría interna | 🟢 |
| [incident-management.md](./incident-management.md) | Clasificación, respuesta y comunicación de incidentes | 🔴 |
| [backup-and-recovery.md](./backup-and-recovery.md) | Backup automático (RNF08), recuperación, pruebas; RPO/RTO; observabilidad | 🟢 |
