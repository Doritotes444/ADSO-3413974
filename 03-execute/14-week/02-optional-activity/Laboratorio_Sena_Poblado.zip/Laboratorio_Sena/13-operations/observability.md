# Observabilidad y Alertas

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Alertas Operativas

### Stock Mínimo Alcanzado (RF03)

- **Disparo:** `stock_actual <= stock_minimo`
- **Mecanismo:** Notificación push vía Firebase Cloud Messaging (FCM) a tablet del admin
- **Pantalla:** Alerta persistente en POS hasta confirmar
- **Formato:** "⚠️ Stock bajo: [Producto] - Quedan [N] unidades"

---

### Crédito Vencido (>30 días sin abono) (RF05)

- **Disparo:** `DATEDIFF(hoy, fecha_ultimo_abono) > 30`
- **Mecanismo:** Marca visual en listado de créditos (cliente en color rojo)
- **Pantalla:** Cliente marcado al abrir módulo de crédito
- **Formato:** "🔴 [Cliente] — Vencido por [N] días"

---

### Diferencia de Caja Alta (≥$5.000 COP) (RF04)

- **Disparo:** `|diferencia| >= 5000`
- **Mecanismo:** Alerta en pantalla de corte antes de confirmar
- **Semáforo:** Rojo
- **Acción:** Admin puede aún confirmar con observación

---

## Auditoría Interna

| Evento | Registrado | Retención |
|--------|-----------|-----------|
| Login | Usuario, timestamp, IP (opcional) | 1 año |
| Cambio de precio | Admin, producto, valor anterior/nuevo, timestamp | 1 año |
| Acceso denegado | Usuario, módulo, timestamp | 1 año |
| Venta confirmada | Empleado, productos, total, método, timestamp | 1 año |
| Corte de caja | Admin, diferencia, observación, timestamp | 1 año |

---

**Backup:** [backup-and-recovery.md](./backup-and-recovery.md)
