# Respaldo y Recuperación

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Respaldo Automático (RNF08)

**Disparador:** Confirmación de CierreCaja (RF04)

**Proceso:**

1. Admin toca "Confirmar Cierre" en Windows
2. Servidor genera dump de BD → archivo SQL o ZIP
3. Intenta subir a Google Drive (requiere credenciales de cuenta de La Esquina)
4. Si éxito → archiva en Drive con nombre: `backup_laesquina_2026-06-23.sql.gz`
5. Si falla (sin conexión) → almacena en servidor local
6. Próxima conexión → reintenta subir

**Frecuencia:** 1 por jornada (al cierre)

**Retención:**

- Google Drive: 30 días
- Local (servidor): Indefinido (hasta limpieza manual)

---

## Recuperación

### Escenario 1: Servidor Disponible, BD Corrupta

1. Descargar backup más reciente de Google Drive
2. Restaurar base de datos:
   ```
   psql -U postgres -d laesquina_db < backup_laesquina_2026-06-23.sql
   ```
3. Verificar integridad con queries de muestra
4. Reiniciar servicio

**Tiempo estimado:** 30 minutos

---

### Escenario 2: Servidor Completo Inaccessible (Fallo de Hardware)

1. Provisionar nuevo servidor
2. Instalar software base (PostgreSQL, API backend, Docker, etc.)
3. Descargar último backup de Google Drive
4. Restaurar BD
5. Actualizar DNS / IP de clientes
6. Reiniciar tablets + navegador Windows

**Tiempo estimado:** 2 horas

**RPO:** 1 día (máximo cierres de caja perdidos si falla servidor entre sincronización)

**RTO:** <2 horas

---

## Pruebas de Recuperación

**Recomendación:** Realizar simulacro mensual

- Restaurar un backup en entorno separado
- Verificar que todos los datos están presentes
- Confirmar integridad de transacciones recientes

---

## Observabilidad

**Alertas recomendadas:**

- "Backup fallido" → Si CierreCaja no se sincroniza a Drive
- "Espacio en disco bajo" → Si almacenamiento del servidor baja de 20 %
- "Conexión BD perdida" → Si API no puede conectar a PostgreSQL

---

**Operaciones:** [observability.md](./observability.md)
