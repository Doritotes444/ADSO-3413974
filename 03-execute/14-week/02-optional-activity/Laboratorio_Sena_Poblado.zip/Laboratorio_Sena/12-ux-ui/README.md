# UX/UI

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta sistema de diseño, navegación y wireframes del producto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [design-system.md](./design-system.md) | Tokens (idioma español, 48×48 dp, 16 sp), colores, tipografía, accesibilidad, elementos comunes | 🟢 |
| [navigation-map.md](./navigation-map.md) | Flujos tablet (POS) y Windows (Admin); estructura de pantallas | 🟢 |
| [wireframes.md](./wireframes.md) | Wireframes detallados: POS, Cobro, Catálogo, Corte, Crédito | 🟢 |
