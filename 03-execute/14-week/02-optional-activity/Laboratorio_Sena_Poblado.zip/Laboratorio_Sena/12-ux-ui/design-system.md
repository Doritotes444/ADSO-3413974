# Sistema de Diseño

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Principios Visuales

### Idioma
- **Español colombiano** en todos los textos, etiquetas, botones
- Sin tecnicismos en inglés visibles
- Ejemplos: "Finalizar Venta" (no "Checkout"), "Efectivo" (no "Cash")

### Accesibilidad en Tablet Android

| Atributo | Requerimiento | Razón |
|----------|--------------|-------|
| **Área de toque mínima** | 48 × 48 dp | Estándar Material Design; evita errores de toque |
| **Tamaño mínimo de fuente** | 16 sp | Legibilidad en mostrador con iluminación variable |
| **Contraste** | WCAG AA (4.5:1) | Accesibilidad visual |
| **Espaciado** | Mínimo 8 dp entre elementos | Evita fatiga visual |

### Colores Base (Sugerencia)
- **Primario:** Azul oscuro (#2E75B6)
- **Secundario:** Gris (#F0F0F0)
- **Éxito:** Verde (#27AE60)
- **Alerta:** Rojo (#E74C3C)
- **Advertencia:** Ámbar (#F39C12)
- **Fondo:** Blanco (#FFFFFF)

---

## Elementos Comunes (Sección 3 del SRS)

### Confirmación de Acciones Destructivas

**Diálogo modal:**
```
┌────────────────────────────────────┐
│  ¿Confirmas la eliminación?       │
│                                    │
│  Se eliminará [PRODUCTO].          │
│  Esta acción no se puede deshacer. │
│                                    │
│  [ Cancelar ]  [ Confirmar ]      │
└────────────────────────────────────┘
```

### Indicador de Modo Offline

**Posición:** Barra superior persistente (siempre visible)

```
┌─────────────────────────────────────┐
│ ⚠️  SIN CONEXIÓN — Modo Offline    │
│     Los datos se sincronizarán     │
│     automáticamente                 │
└─────────────────────────────────────┘
```

**Cambio de estado:** Desaparece automáticamente al recuperar conexión.

### Retroalimentación de Operaciones

**Almacenando:**
```
[ Guardando... ] ⏳
```

**Éxito:**
```
✅ Venta registrada
```

**Error:**
```
❌ Error: Nombre de producto duplicado.
   Por favor, elige otro nombre.
```

---

## Tipografía (Tablet Android)

| Elemento | Fuente | Tamaño | Peso |
|----------|--------|--------|------|
| **Título de pantalla** | Sans-serif | 24 sp | Bold |
| **Subtítulos** | Sans-serif | 18 sp | Medium |
| **Cuerpo** | Sans-serif | 16 sp | Regular |
| **Botones** | Sans-serif | 16 sp | Medium |
| **Leyendas** | Sans-serif | 12 sp | Regular |

---

## Consistencia Visual

- Botón principal ("Finalizar Venta"): Azul primario, posición fija inferior derecha
- Botón secundario ("Cancelar"): Gris, igual tamaño
- Campos numéricos: Alineación derecha (precios, cantidades)
- Campos de texto: Alineación izquierda

---

**Navegación:** [navigation-map.md](./navigation-map.md) | **Wireframes:** [wireframes.md](./wireframes.md)
