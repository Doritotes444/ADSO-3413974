# Mapa de Navegación

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Flujo Tablet Android (Mostrador — Operarios)

```
┌─────────────────────────────────────┐
│    PANTALLA PRINCIPAL (POS)        │
│                                    │
│  ┌─────────────────────────────┐  │
│  │ 🔍 Buscar producto...      │  │
│  └─────────────────────────────┘  │
│                                    │
│  Productos Recientes:              │
│  ┌────┬────┬────┐                 │
│  │Lec │Pau │Pan │ ...             │
│  │$800│$300│$200│                 │
│  └────┴────┴────┘                 │
│                                    │
│  ┌─────────────────────────────┐  │
│  │    CARRITO ACTUAL           │  │
│  │ - Pan × 2     $200 × 2      │  │
│  │ - Leche × 1   $800 × 1      │  │
│  │ ─────────────────────────   │  │
│  │ SUBTOTAL:     $1.200        │  │
│  └─────────────────────────────┘  │
│                                    │
│      [ FINALIZAR VENTA 🛒 ]       │
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│     PANTALLA DE COBRO               │
│                                    │
│  TOTAL:  $1.200                    │
│  ─────────────────                 │
│  Efectivo recibido: [ 1.500 ]      │
│  ─────────────────                 │
│  CAMBIO: $300                      │
│                                    │
│  Método de pago:                   │
│  [ EFECTIVO ]  [ DIGITAL ]         │
│                                    │
│     [ CONFIRMAR VENTA ]            │
│     [ CANCELAR ]                   │
└─────────────────────────────────────┘
           ↓
        Tiquete
     (Imprimir / WhatsApp)
           ↓
     Vuelve a POS
```

---

## Flujo Windows 10 (Oficina — Admin)

### Pantalla Principal (Dashboard)

```
┌──────────────────────────────────────┐
│     PANEL ADMINISTRATIVO             │
│                                      │
│  [ 📦 Catálogo ]                    │
│  [ 💰 Corte de Caja ]              │
│  [ 💳 Gestión de Crédito ]         │
│  [ 📊 Reportes (opcional) ]         │
└──────────────────────────────────────┘
```

### 1. Gestión de Catálogo

```
Barra de búsqueda: [ Buscar por nombre... ]

Categoría: [ Abarrotes ▼ ]

┌────────────────────────────────────────┐
│ Nombre     │ Categoría  │ Precio │ Stock
├────────────────────────────────────────┤
│ Leche      │ Lácteos    │ $800   │ 45
│ Pan        │ Panadería  │ $200   │ 120
│ Huevos     │ Lácteos    │ $1200  │ 8 🔴
├────────────────────────────────────────┤
│                    [ + Nuevo ] [ ⋮ ... ]
└────────────────────────────────────────┘
```

### 2. Corte de Caja

```
┌────────────────────────────────────────┐
│  CORTE DE CAJA — 2026-06-23           │
│                                        │
│  Total efectivo:     $15.500           │
│  Total digital:      $8.200            │
│  Transacciones:      23                │
│                                        │
│  Desglose por empleado:                │
│  Carlos:    $8.200                     │
│  Martha:    $7.800                     │
│  Julián:    $4.500                     │
│  Diego:     $3.200                     │
│                                        │
│  Efectivo en caja (física): [ 15500 ]  │
│  ─────────────────────────────         │
│  Diferencia: $0          🟢 Verde      │
│                                        │
│  Observación: [ ..................... ]│
│                                        │
│  [ CONFIRMAR CIERRE ]  [ CANCELAR ]   │
│  [ Exportar PDF ]                     │
└────────────────────────────────────────┘
```

### 3. Gestión de Crédito

```
┌────────────────────────────────────────┐
│  CLIENTES CON CRÉDITO ACTIVO          │
│                                        │
│ Nombre    │ Monto │ Abonado │ Pendiente
├────────────────────────────────────────┤
│ Don José  │ $50K  │ $20K    │ $30K
│ Doña Marta│ $25K  │ $25K    │ $0   ✅
│ Gonzalo   │ $40K  │ $10K    │ $30K 🔴
├────────────────────────────────────────┤
│                 [ + Registrar Crédito ]
└────────────────────────────────────────┘

🔴 = >30 días sin abono
```

---

**Wireframes detallados:** [wireframes.md](./wireframes.md) | **Design System:** [design-system.md](./design-system.md)
