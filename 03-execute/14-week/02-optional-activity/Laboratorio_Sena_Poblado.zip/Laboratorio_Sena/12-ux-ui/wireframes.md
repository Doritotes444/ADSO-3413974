# Wireframes

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Tablet Android — Pantalla Principal (POS)

**Descripción:** Interfaz de venta sin barra lateral. Cuadrícula de productos, barra de búsqueda siempre visible, carrito activo en mitad inferior.

**Elementos:**

- Barra superior: Logo + indicador de modo offline (si aplica)
- Barra de búsqueda: Campo de texto con teclado automático
- Cuadrícula de productos: Cards verticales con imagen de referencia, nombre, precio
- Carrito: Tabla con ProductoVendido, cantidad, precio unitario, subtotal
- Botón fijo (inferior derecha): "Finalizar Venta" (48×48 dp mínimo)

**Layout:** Pantalla completa (sin barra lateral) para aprovechar 7–10 pulgadas

---

## Tablet Android — Pantalla de Cobro

**Descripción:** Total en tipografía grande (32 sp mínimo), campo para efectivo recibido, cambio calculado automáticamente.

**Elementos:**

- Encabezado: Título "Cobro"
- Campo grande: TOTAL en fuente 32 sp
- Campo de entrada: "Efectivo recibido" (abre teclado numérico automáticamente)
- Resultado: "CAMBIO: $XXX" (calculado en tiempo real)
- Selector de método: Radio buttons [EFECTIVO] [DIGITAL]
- Botones de acción: "Confirmar Venta" (primario), "Cancelar" (secundario)

---

## Windows 10 — Gestión de Catálogo

**Descripción:** Tabla de productos con columnas ordenables, filtro de categoría lateral, búsqueda por nombre.

**Elementos:**

- Panel lateral izquierdo: Filtro por categoría (dropdown o checkbox list)
- Barra superior: Campo de búsqueda por nombre
- Tabla central: 
  - Columnas: Nombre, Categoría, Precio, Stock Actual, Stock Mínimo, Acciones
  - Ordenamiento al hacer clic en encabezado
  - Iconos: ✏️ Editar, 🗑️ Eliminar (con confirmación)
- Botón flotante: "+ Nuevo Producto"

---

## Windows 10 — Corte de Caja

**Descripción:** Tarjetas de indicadores (KPIs), tabla de desglose por empleado, campo de entrada de efectivo físico, semáforo.

**Elementos:**

- Encabezado: Título + fecha del corte
- Cards de KPIs: 
  - Total Efectivo: $XX.XXX
  - Total Digital: $XX.XXX
  - Número de Transacciones: XX
- Tabla de desglose: Empleado | Total Ventas
- Campo: "Efectivo en caja (contado): [ ]" (numérico)
- Indicador visual: Semáforo (verde/amarillo/rojo) según diferencia
- Texto libre: "Observación:" [ ]
- Botones: "Confirmar Cierre", "Cancelar", "Exportar PDF"

---

## Windows 10 — Gestión de Crédito

**Descripción:** Listado de clientes con crédito activo, alertas por morosidad, formulario de abono.

**Elementos:**

- Tabla:
  - Columnas: Nombre, Monto Inicial, Abonado, Saldo Pendiente, Días Sin Abono, Acciones
  - Filas con >30 días sin abono: Destacadas en rojo
- Botón: "+ Registrar Nuevo Crédito"
- Sección de abono (modal o página dedicada):
  - Selector de cliente
  - Monto a abonar (numérico)
  - Observación (texto opcional)
  - "Registrar Abono"

---

## Comportamientos Interactivos

### Búsqueda de Producto (Tablet)

1. Usuario toca campo de búsqueda
2. Teclado en pantalla se abre automáticamente
3. Mientras tipea, filtrar productos en tiempo real
4. Tocar producto → agregar al carrito con cantidad = 1

### Cambio de Precio (Windows)

1. Admin toca icono ✏️ en producto
2. Navega a página de edición
3. Modifica precio, valida que no esté vacío ni sea negativo
4. Toca "Guardar"
5. Precio visible en POS de tablet en <5 segundos

### Validación de Duplicado

```
Admin intenta crear producto "Leche"
↓
Sistema comprueba: ¿existe nombre "Leche"?
↓ SÍ → Muestra error en línea junto al campo:
"❌ Este nombre ya existe"
↓ NO → Crea producto
```

---

**Design System:** [design-system.md](./design-system.md) | **Navegación:** [navigation-map.md](./navigation-map.md)
