# Diccionario de Datos

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Producto

| Campo | Tipo | Validación | Descripción |
|-------|------|-----------|-------------|
| `id` | UUID | PK | Identificador único |
| `nombre` | VARCHAR(255) | UNIQUE, NOT NULL | Nombre del producto; no puede repetirse |
| `precio_venta` | DECIMAL(10,2) | NOT NULL, > 0 | Precio en COP; debe ser positivo |
| `categoria_id` | FK | NOT NULL | Referencia a Categoría |
| `stock_actual` | INT | NOT NULL, >= 0 | Cantidad disponible; se decrementa al vender |
| `stock_minimo` | INT | NOT NULL, >= 0 | Umbral para generar alerta (RF03) |
| `descripcion` | TEXT | nullable | Información adicional |
| `creado_en` | TIMESTAMP | NOT NULL | Fecha creación del registro |
| `actualizado_en` | TIMESTAMP | NOT NULL | Última actualización |

---

## Venta

| Campo | Tipo | Validación | Descripción |
|-------|------|-----------|-------------|
| `id` | UUID | PK | Identificador único de venta |
| `empleado_id` | FK | NOT NULL | Quién registró la venta |
| `fecha` | DATE | NOT NULL | Fecha de la transacción |
| `hora` | TIME | NOT NULL | Hora de la transacción (registrada automáticamente) |
| `subtotal` | DECIMAL(10,2) | NOT NULL, >= 0 | Suma de ItemVenta (cantidad × precio) |
| `impuesto` | DECIMAL(10,2) | NOT NULL, >= 0 | IVA u otro impuesto aplicable |
| `total` | DECIMAL(10,2) | NOT NULL, >= 0 | subtotal + impuesto |
| `metodo_pago` | ENUM | NOT NULL | 'EFECTIVO' o 'DIGITAL' |
| `estado` | ENUM | NOT NULL | 'CONFIRMADA' o 'ANULADA' |
| `creado_en` | TIMESTAMP | NOT NULL | Timestamp de creación |

---

## Credito

| Campo | Tipo | Validación | Descripción |
|-------|------|-----------|-------------|
| `id` | UUID | PK | Identificador único |
| `cliente_nombre` | VARCHAR(255) | NOT NULL | Nombre del cliente acreedor |
| `monto_inicial` | DECIMAL(10,2) | NOT NULL, > 0 | Cantidad inicial del crédito |
| `saldo_pendiente` | DECIMAL(10,2) | NOT NULL, >= 0 | monto_inicial − suma de abonos |
| `fecha_otorgamiento` | DATE | NOT NULL | Día que se concedió el crédito |
| `estado` | ENUM | NOT NULL | 'ACTIVO' si saldo > 0; 'CERRADO' si saldo = 0 |
| `dias_sin_abono` | INT | Calculado | Días desde último Abono; >= 30 → alerta (RF05) |
| `creado_en` | TIMESTAMP | NOT NULL | Timestamp de creación |

---

## Abono

| Campo | Tipo | Validación | Descripción |
|-------|------|-----------|-------------|
| `id` | UUID | PK | Identificador único |
| `credito_id` | FK | NOT NULL | Referencia al crédito pagado |
| `monto` | DECIMAL(10,2) | NOT NULL, > 0 | Cantidad abonada (≤ saldo pendiente actual) |
| `fecha` | DATE | NOT NULL | Fecha del abono (registrada automáticamente) |
| `observacion` | TEXT | nullable | Nota del admin (ej: "Pago en efectivo") |
| `creado_en` | TIMESTAMP | NOT NULL | Timestamp de creación |

---

## CierreCaja

| Campo | Tipo | Validación | Descripción |
|-------|------|-----------|-------------|
| `id` | UUID | PK | Identificador único del cierre |
| `fecha` | DATE | NOT NULL | Día del cierre |
| `efectivo_registrado` | DECIMAL(10,2) | NOT NULL, >= 0 | Total de ventas en efectivo (del sistema) |
| `efectivo_fisico` | DECIMAL(10,2) | NOT NULL, >= 0 | Efectivo contado en caja (ingresado por admin) |
| `diferencia` | DECIMAL(10,2) | Calculado | efectivo_fisico − efectivo_registrado; si >= $5000 → alerta |
| `observacion` | TEXT | nullable | Justificación de diferencias |
| `estado` | ENUM | NOT NULL | 'ABIERTO' o 'CERRADO' |
| `admin_id` | FK | NOT NULL | Admin que hizo el cierre |
| `creado_en` | TIMESTAMP | NOT NULL | Timestamp |

---

**Modelos:** [models.md](./models.md)
