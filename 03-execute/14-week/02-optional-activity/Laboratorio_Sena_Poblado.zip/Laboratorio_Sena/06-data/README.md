# Datos

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Documenta modelos de datos, diccionario y esquema de persistencia.

> **Diferencia con `02-domain`:** aquí viven tablas, columnas, tipos, índices, migraciones. Las entidades de negocio van en [`02-domain/`](../02-domain/).

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [models.md](./models.md) | Entidades de persistencia (Producto, Venta, Crédito, etc.) — estructura SQL conceptual | 🟢 |
| [data-dictionary.md](./data-dictionary.md) | Diccionario detallado de campos, tipos, validaciones | 🟢 |
| [migration-strategy.md](./migration-strategy.md) | Estrategia de evolución de esquema (referencia a sincronización offline) | 🔴 |
