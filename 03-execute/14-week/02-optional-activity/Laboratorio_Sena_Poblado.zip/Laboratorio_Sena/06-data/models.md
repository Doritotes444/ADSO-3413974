# Modelos de Datos

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Entidades Principales

### Producto

```
id (UUID, PK)
nombre (VARCHAR 255, UNIQUE)
precio_venta (DECIMAL 10.2, > 0)
categoria_id (FK → Categoria)
stock_actual (INT, >= 0)
stock_minimo (INT, >= 0)
descripcion (TEXT, nullable)
creado_en (TIMESTAMP)
actualizado_en (TIMESTAMP)
```

### Categoria

```
id (UUID, PK)
nombre (VARCHAR 100, UNIQUE)
descripcion (TEXT, nullable)
```

### Venta

```
id (UUID, PK)
empleado_id (FK → Empleado)
fecha (DATE)
hora (TIME)
subtotal (DECIMAL 10.2)
impuesto (DECIMAL 10.2)
total (DECIMAL 10.2)
metodo_pago (ENUM: 'EFECTIVO', 'DIGITAL')
estado (ENUM: 'CONFIRMADA', 'ANULADA')
creado_en (TIMESTAMP)
```

### ItemVenta

```
id (UUID, PK)
venta_id (FK → Venta)
producto_id (FK → Producto)
cantidad (INT, > 0)
precio_unitario (DECIMAL 10.2)
subtotal (DECIMAL 10.2)
```

### Empleado

```
id (UUID, PK)
nombre (VARCHAR 255, UNIQUE)
rol (ENUM: 'ADMINISTRADOR', 'EMPLEADO')
estado (ENUM: 'ACTIVO', 'INACTIVO')
creado_en (TIMESTAMP)
```

### Credito

```
id (UUID, PK)
cliente_nombre (VARCHAR 255)
monto_inicial (DECIMAL 10.2)
saldo_pendiente (DECIMAL 10.2)
fecha_otorgamiento (DATE)
estado (ENUM: 'ACTIVO', 'CERRADO')
dias_sin_abono (INT, calculado)
creado_en (TIMESTAMP)
```

### Abono

```
id (UUID, PK)
credito_id (FK → Credito)
monto (DECIMAL 10.2)
fecha (DATE)
observacion (TEXT, nullable)
creado_en (TIMESTAMP)
```

### CierreCaja

```
id (UUID, PK)
fecha (DATE)
efectivo_registrado (DECIMAL 10.2)
efectivo_fisico (DECIMAL 10.2)
diferencia (DECIMAL 10.2, calculado)
observacion (TEXT, nullable)
estado (ENUM: 'ABIERTO', 'CERRADO')
admin_id (FK → Empleado)
creado_en (TIMESTAMP)
```

### Tiquete

```
id (UUID, PK)
venta_id (FK → Venta)
contenido_html (TEXT)
formato (ENUM: 'IMPRESO', 'PDF_WHATSAPP')
generado_en (TIMESTAMP)
```

---

**Diccionario:** [data-dictionary.md](./data-dictionary.md)
