# UML

> Estado: 🔴 Pendiente | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Repositorio de diagramas UML y arquitectura visual.

## Diagramas Pendientes (Derivados del SRS)

| Diagrama | Origen SRS | Tipo | Fuente | Exportación |
|----------|-----------|------|--------|------------|
| Casos de Uso | RF01–RF07 | Use Case | `casos-uso.wsd` | `casos-uso.svg` |
| Clases (Entidades) | Secc. 6.2 + 02-domain | Class | `dominio-class.wsd` | `dominio-class.svg` |
| Actividad (Venta) | Flujo RF01 + RF03 + RF06 | Activity | `venta-activity.wsd` | `venta-activity.svg` |
| Secuencia (Sincronización) | Secc. 7.3 | Sequence | `sync-sequence.wsd` | `sync-sequence.svg` |

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [diagram-index.md](./diagram-index.md) | Índice de diagramas fuente y exportaciones | 🔴 |
| [diagrams/source/](./diagrams/source/) | Fuentes editables `.wsd` | 🔴 |
| [diagrams/exports/](./diagrams/exports/) | Exportaciones SVG | 🔴 |
