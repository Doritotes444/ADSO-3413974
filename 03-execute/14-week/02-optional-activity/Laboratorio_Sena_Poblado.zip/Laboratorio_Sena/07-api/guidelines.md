# Lineamientos de API

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Convenciones de Transporte

**Protocolo:** HTTPS / REST (sin HTTP sin cifrado)

**Formato de Respuesta:** JSON

**Códigos HTTP:** Ver [05-architecture/cross-cutting.md](../05-architecture/cross-cutting.md)

---

## Estructura de Petición

```
POST /api/v1/ventas
Authorization: Bearer eyJhbGc...
Content-Type: application/json

{
  "empleado_id": "uuid",
  "items": [
    {"producto_id": "uuid", "cantidad": 2},
    {"producto_id": "uuid", "cantidad": 1}
  ],
  "metodo_pago": "EFECTIVO"
}
```

---

## Estructura de Respuesta Exitosa

```json
{
  "success": true,
  "data": {
    "id": "venta-uuid",
    "total": 45000,
    "estado": "CONFIRMADA",
    "timestamp": "2026-06-23T14:30:00Z"
  }
}
```

## Estructura de Respuesta de Error

```json
{
  "success": false,
  "error": "Nombre de producto duplicado",
  "code": "DUPLICATE_NAME",
  "timestamp": "2026-06-23T14:30:00Z"
}
```

---

## Versionado

Todas las rutas usan prefijo `/api/v1/`. Cambios backward-compatible no requieren versión nueva. Cambios disruptivos → `/api/v2/`.

---

**Autenticación:** [authentication.md](./authentication.md) | **Contratos:** `contracts/openapi/`
