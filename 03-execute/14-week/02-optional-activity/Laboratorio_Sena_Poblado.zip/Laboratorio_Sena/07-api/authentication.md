# Autenticación y Autorización

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## JWT (JSON Web Token)

**Emisión:**

- **Endpoint:** `POST /api/v1/auth/login`
- **Entrada:** `{ "usuario": "nombre", "contraseña": "..." }`
- **Salida:** `{ "token": "eyJhbGc...", "expira_en": 86400 }`
- **Validez:** 24 horas (ajustable)

**Payload:**

```json
{
  "sub": "uuid-usuario",
  "nombre": "Carlos Ruiz",
  "rol": "ADMINISTRADOR",
  "iat": 1687536600,
  "exp": 1687623000
}
```

---

## Validación en Cada Petición

1. Cliente incluye token: `Authorization: Bearer <token>`
2. Servidor valida:
   - Firma del token (RS256 o HS256)
   - Expiración (`exp` > ahora)
   - Presencia de `rol`
3. Si válido → ejecuta operación
4. Si inválido → `401 Unauthorized` o `403 Forbidden`

---

## Almacenamiento Seguro (Cliente)

**Android:**
- Usar `SharedPreferences` encriptado (EncryptedSharedPreferences)
- NUNCA almacenar en texto plano

**Windows/Web:**
- Usar `sessionStorage` (no persiste tras cerrar pestaña)
- O `localStorage` con HTTPS obligatorio
- NUNCA exponer en cookies HTTP

---

## Control de Acceso por Rol

Ver tabla en [05-architecture/cross-cutting.md](../05-architecture/cross-cutting.md)

---

## Revocación de Token

Token sin revocación explícita (simplemente expira a las 24h). Para logout inmediato: cliente descarta token localmente.

Para revocación forzada (cambio de contraseña, etc.): servidor puede mantener lista negra de tokens revocados (caro para escala; MVP no requiere).

---

**API Rest:** [guidelines.md](./guidelines.md)
