# API

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Define lineamientos de API, autenticación y ubicación de contratos OpenAPI.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [guidelines.md](./guidelines.md) | Convenciones: HTTPS, JSON, códigos HTTP, versionado `/api/v1/` | 🟢 |
| [authentication.md](./authentication.md) | JWT: emisión, validación, almacenamiento seguro, control de acceso por rol | 🟢 |
| [contracts/openapi/](./contracts/openapi/) | Contratos OpenAPI (a completar en fase de desarrollo) | 🔴 |
