# Arquitectura

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Describe la arquitectura del sistema, despliegue, decisiones técnicas y aspectos transversales.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [overview.md](./overview.md) | Patrón cliente-servidor offline-first; topología; componentes | 🟢 |
| [deployment.md](./deployment.md) | Especificaciones de hardware; ambientes; sincronización offline; backup y RTO/RPO | 🟢 |
| [cross-cutting.md](./cross-cutting.md) | JWT; control de acceso por roles; códigos HTTP; validación; logging; errores; índices de BD | 🟢 |
| [decisions/](./decisions/) | Registro de Decisiones de Arquitectura (ADR) — a completar | 🔴 |
