# Despliegue e Infraestructura

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Ambientes

### Producción

**Tablet Android — Mostrador**

| Componente | Especificación |
|-----------|----------------|
| **Sistema operativo** | Android 8.0 (API Level 26) o superior |
| **RAM mínima** | 2 GB (referencia base para RNF03) |
| **Almacenamiento** | Mínimo 8 GB internos (app + BD local + backups) |
| **Pantalla** | Mínimo 7 pulgadas, 48×48 dp visible, 16 sp legible |
| **Conectividad** | Wi-Fi o datos móviles; opera offline si se cae |
| **Impresora (opcional)** | Térmica vía Bluetooth/USB (RFC06) |

**Computador Windows 10 — Oficina Administrativa**

| Componente | Especificación |
|-----------|----------------|
| **Sistema operativo** | Windows 10 o superior |
| **RAM mínima** | 2 GB (típico de microempresas) |
| **Navegador** | Chrome, Firefox o Edge actualizados |
| **Conectividad** | Wi-Fi domiciliario para sincronización |
| **Hardware adicional** | Ninguno especializado |

---

## Backend — Servidor Centralizado

**Requisitos mínimos:**

- **CPU:** 2 vCPU (t3.small en AWS o equivalente)
- **RAM:** 2 GB
- **BD:** PostgreSQL 15+ con almacenamiento mínimo de 10 GB (crecimiento estimado)
- **Conectividad:** HTTPS/TLS 1.2+
- **Respaldos:** Automático a Google Drive diariamente

**Alojamiento sugerido (para SENA/pruebas):**
- AWS EC2 (t3.small) + RDS PostgreSQL
- Google Cloud Platform (Compute Engine + Cloud SQL)
- DigitalOcean (Droplet + Managed PostgreSQL)
- En local (VPS doméstico con router con IP pública) — no recomendado para producción

---

## Sincronización Offline → Online

**Mecanismo:** 

1. **Detección de conexión:** App monitorea estado de red continuo
2. **Caché local:** Registros pendientes en SQLite quedan marcados como `synced = false`
3. **Reconexión:** Al detectar conexión, inicia sincronización asíncrona
4. **Batching:** Agrupa múltiples registros en pocas peticiones para reducir latencia
5. **Confirmación:** Servidor responde; cliente marca registros como `synced = true`
6. **Plazo:** <5 minutos desde reconexión (RNF02)

**Manejo de conflictos:** Last-write-wins (servidor tiene autoridad; descarta cambios locales posteriores a la última sincronización si hay conflicto)

---

## Respaldo y Recuperación

**Respaldo Automático (RNF08):**

- Disparador: Confirmación de CierreCaja
- Destino primario: Google Drive (credenciales de la cuenta de La Esquina)
- Destino contingencia: Almacenamiento local en servidor
- Frecuencia: Diaria (1 por jornada)
- Retención: 30 días en Google Drive; local indefinido

**Recuperación:**

- Procedimiento manual: Descargar backup desde Google Drive, restaurar BD local/servidor
- Tiempo estimado: <1 hora
- RPO (Recovery Point Objective): 1 día (máximo cierres de caja perdidos si falla servidor)
- RTO (Recovery Time Objective): <2 horas (reinstalar app + restaurar datos)

---

## CI/CD (Sugerido para Futuro)

- **Repositorio:** GitHub/GitLab
- **Pipeline:** GitHub Actions / GitLab CI
- **Etapas:** Tests automáticos → Build app + servidor → Deploy a staging → Manual approval → Deploy a producción

---

**Seguridad y transversales:** [cross-cutting.md](./cross-cutting.md) | **Arquitectura general:** [overview.md](./overview.md)
