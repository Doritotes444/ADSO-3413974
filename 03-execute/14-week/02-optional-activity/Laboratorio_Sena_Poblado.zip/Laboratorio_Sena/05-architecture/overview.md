# Arquitectura del Sistema

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

## Patrón General: Cliente-Servidor con Offline-First

El sistema adopta una arquitectura **cliente-servidor distribuida con operación offline** para garantizar disponibilidad en presencia de conectividad inestable.

### Topología

```
┌─────────────────────────────────────────────────────────┐
│                   Tablet Android                        │
│              (Mostrador — POS Operarios)               │
│                                                         │
│  ┌─────────────────────────────────────────────────┐  │
│  │  Aplicación Android (React Native / Flutter)   │  │
│  │  ├─ Módulo de Ventas (RF01)                   │  │
│  │  ├─ Consulta de Inventario (RF02 lectura)    │  │
│  │  └─ Recepción de alertas (RF03, RF05)        │  │
│  └─────────────────────────────────────────────────┘  │
│                         ↓ (SQLite)                      │
│  ┌─────────────────────────────────────────────────┐  │
│  │   Base de Datos Local (SQLite Embebida)       │  │
│  │   ├─ Catálogo de productos                     │  │
│  │   ├─ Historial de ventas (offline)             │  │
│  │   ├─ Registros de crédito                      │  │
│  │   └─ Cola de sincronización                    │  │
│  └─────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
           ↓↑ HTTPS/REST (≤5 min al recuperar conexión)
┌─────────────────────────────────────────────────────────┐
│                  Servidor Backend                       │
│  (Centraliza estado, autorización, persistencia)       │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │  API REST (Go/Gin o equivalente)               │ │
│  │  ├─ /ventas (POST crear, GET listar)          │ │
│  │  ├─ /productos (CRUD)                          │ │
│  │  ├─ /creditos (CRUD)                           │ │
│  │  ├─ /cierres (POST, exportar PDF)             │ │
│  │  └─ /auth (login, obtener JWT)                │ │
│  └──────────────────────────────────────────────────┘ │
│               ↓ (validación JWT)                        │
│  ┌──────────────────────────────────────────────────┐ │
│  │  Base de Datos Relacional (PostgreSQL 15+)     │ │
│  │  ├─ Tabla Producto, Categoría, Venta, etc.    │ │
│  │  ├─ Índices en campos frecuentes (RNF03)      │ │
│  │  └─ Respaldos automáticos diarios (RNF08)    │ │
│  └──────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
                         ↓
┌─────────────────────────────────────────────────────────┐
│          Computador Windows 10 (Oficina Admin)         │
│                                                         │
│  ┌──────────────────────────────────────────────────┐ │
│  │  Navegador Web (Chrome/Firefox/Edge)           │ │
│  │  ├─ Gestión de Catálogo (RF02 edición)        │ │
│  │  ├─ Corte de Caja (RF04)                       │ │
│  │  ├─ Gestión de Créditos (RF05)                │ │
│  │  └─ Reportes (RF07 opcional)                   │ │
│  └──────────────────────────────────────────────────┘ │
│                (JWT en localStorage/sessionstorage)   │
└─────────────────────────────────────────────────────────┘
                         ↓
            Google Drive (Respaldos automáticos)
                   (RNF08)
```

### Componentes Clave

| Componente | Tecnología | Responsabilidad |
|-----------|-----------|-----------------|
| **Cliente Tablet** | Android 8.0+, app nativa o React Native | Interfaz POS, persistencia offline, sincronización |
| **Cliente Web** | SPA (React 18 + TypeScript) | Panel administrativo |
| **Backend** | Go 1.21+ con Gin, o equivalente | API REST, lógica de negocio, validación de JWT |
| **Base Local** | SQLite | Persistencia offline en tablet |
| **Base Central** | PostgreSQL 15+ | Persistencia centralizada, respaldos |
| **Almacenamiento** | Google Drive API | Backup automático diario |
| **Autenticación** | JWT (RS256 o HS256) | Sin estado, seguro entre cliente-servidor |
| **Notificaciones Push** | Firebase Cloud Messaging (FCM) | Alertas de stock mínimo al admin |

---

## Flujos Principales

### Flujo 1: Venta Confirmada (RNF02 — Offline)

1. Operario selecciona productos en tablet (app offline o online)
2. Sistema calcula total automáticamente
3. Al confirmar venta:
   - Si **online:** envía venta al servidor HTTPS, recibe confirmación
   - Si **offline:** persiste en SQLite local, entra a cola de sincronización
4. Automáticamente descuenta stock (RF03)
5. Genera tiquete (RF06)
6. Al recuperar conexión: sincroniza en <5 min (RNF02)

**Tiempos críticos:** Venta → Tiquete ≤3 seg (RNF03, hardware mínimo)

---

### Flujo 2: Respaldo Automático Diario (RNF08)

1. Admin confirma corte de caja (RF04)
2. Backend genera backup de la BD
3. Si hay conexión: sube a Google Drive automáticamente
4. Si sin conexión: almacena localmente
5. Próxima sincronización: intenta subir backup local a Drive

---

## Aspectos Transversales

- **Seguridad:** JWT en cada petición; bloqueo de accesos no autorizados (RNF04)
- **Logging:** Auditoría de intentos de acceso, cambios de precios, cierres de caja
- **Errores:** Códigos HTTP semánticos (200, 201, 400, 403, 409, 500) con mensajes amigables
- **Performance:** Índices en BD para búsquedas frecuentes; caché local en cliente

---

**Más detalles:** [deployment.md](./deployment.md) | [cross-cutting.md](./cross-cutting.md)
