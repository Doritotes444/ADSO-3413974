# Aspectos Transversales

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Autenticación y Autorización (RNF04)

### JWT (JSON Web Token)

**Flujo:**

1. Usuario inicia sesión (email/nombre + contraseña opcional)
2. Servidor valida credenciales
3. Servidor emite JWT con:
   - `sub` (ID usuario)
   - `role` ("Administrador" o "Empleado")
   - `exp` (expiración, ej: 24 horas)
4. Cliente almacena JWT de forma segura (no texto plano)
5. Cada petición incluye: `Authorization: Bearer <jwt>`
6. Servidor valida JWT antes de ejecutar operación

### Control de Acceso por Rol

| Módulo | Administrador | Empleado |
|--------|---|---|
| **Registro de Venta (RF01)** | ✅ | ✅ |
| **Catálogo — lectura (RF02)** | ✅ | ✅ |
| **Catálogo — edición (RF02)** | ✅ | ❌ Bloqueado |
| **Inventario — consulta (RF03)** | ✅ | ✅ (solo lectura) |
| **Corte de Caja (RF04)** | ✅ | ❌ Bloqueado |
| **Gestión de Crédito (RF05)** | ✅ | ❌ Bloqueado |
| **Generación de Tiquete (RF06)** | ✅ | ✅ |
| **Historial de Ventas (RF07)** | ✅ (todas) | ✅ (solo propias) |

**Intento de acceso no autorizado:**
- Servidor devuelve `403 Forbidden`
- Se registra en auditoría (no se notifica al usuario; auditoría interna)

---

## API REST — Códigos de Respuesta HTTP

| Código | Significado | Caso de uso |
|--------|-----------|-----------|
| **200 OK** | Operación exitosa (GET, PUT) | Listar productos, actualizar precio |
| **201 Created** | Recurso creado (POST) | Crear venta, crear crédito |
| **400 Bad Request** | Datos inválidos | Precio vacío, nombre duplicado, cantidad negativa |
| **403 Forbidden** | Permiso insuficiente | Empleado intenta editar producto |
| **404 Not Found** | Recurso no existe | Producto ID inválido |
| **409 Conflict** | Conflicto de estado | Nombre duplicado, venta de producto con stock = 0 |
| **500 Internal Server Error** | Error del servidor | BD inaccesible, error no manejado (mensaje genérico amigable) |

**Ejemplo de respuesta de error:**

```json
{
  "error": "Nombre de producto duplicado",
  "code": "DUPLICATE_NAME",
  "timestamp": "2026-06-23T14:30:00Z"
}
```

---

## Validación de Operaciones Destructivas

**Confirmación explícita requerida:**

- Eliminar un producto
- Eliminar un registro de crédito
- Anular una venta (futuro)

**Diálogo de confirmación:**

- Título: "¿Confirmas la eliminación?"
- Descripción: "Se eliminará [nombre del producto]. Esta acción no se puede deshacer."
- Botones: "Confirmar" / "Cancelar"

---

## Mensajes de Error Comprensibles

**Principios:**

1. Usar lenguaje simple en español colombiano
2. Indicar qué salió mal (no códigos de error genéricos)
3. Mostrar dónde salió mal (línea del campo)
4. Sugerir acción correctiva

**Ejemplos:**

- ❌ "Error 400"
- ✅ "El precio debe ser mayor a $0"

- ❌ "Constraint violation on unique index"
- ✅ "Este nombre de producto ya existe. Por favor, elige otro."

- ❌ "Network timeout"
- ✅ "No hay conexión a internet. Tu venta se guardó localmente y se sincronizará automáticamente cuando vuelva la conexión."

---

## Logging y Auditoría

**Eventos registrados:**

| Evento | Qué se registra | Auditoría |
|--------|----------------|-----------|
| **Login** | Usuario, rol, timestamp, IP (si aplica) | Sí |
| **Cambio de precio** | Admin, producto, precio anterior, precio nuevo, timestamp | Sí |
| **Venta confirmada** | Empleado, productos, total, método de pago, timestamp | Sí |
| **Corte de caja** | Admin, diferencia, observación, timestamp | Sí |
| **Acceso no autorizado** | Usuario, módulo intento, timestamp | Sí |
| **Sincronización completada** | Dispositivo, registros sincronizados, timestamp | Información |

**Retención:** Mínimo 1 año para auditoría.

---

## Manejo de Errores en Modo Offline

**Escenarios:**

1. **Venta sin conexión:**
   - Sistema persiste en SQLite
   - Usuario ve confirmación: "Venta guardada localmente. Se sincronizará al volver la conexión."
   - No se interrumpe la venta

2. **Cambio de catálogo sin conexión (Admin en Windows):**
   - Cambio no permitido (requiere conexión)
   - Mensaje: "Debe estar conectado a internet para cambiar precios. Por favor, verifica tu conexión."

3. **Sincronización fallida:**
   - Sistema reintenta automáticamente en <5 minutos
   - Si falsa persistentemente (>1 hora), notificar admin: "Datos pendientes: [N] ventas no sincronizadas"

---

## Performance — Índices de BD

**Campos indexados (para cumplir RNF03 ≤3 seg):**

```sql
CREATE INDEX idx_producto_nombre ON Producto(nombre);
CREATE INDEX idx_venta_empleado_fecha ON Venta(empleado_id, fecha);
CREATE INDEX idx_itemventa_venta ON ItemVenta(venta_id);
CREATE INDEX idx_itemventa_producto ON ItemVenta(producto_id);
CREATE INDEX idx_credito_cliente ON Credito(cliente_nombre);
CREATE INDEX idx_abono_credito_fecha ON Abono(credito_id, fecha);
```

---

**Seguridad:** JWT + HTTPS | **Autenticación:** [07-api/authentication.md](../07-api/authentication.md)
