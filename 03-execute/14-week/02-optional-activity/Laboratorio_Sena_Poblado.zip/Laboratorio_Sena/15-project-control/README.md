# Control de Proyecto

> Estado: 🟢 Estable | Última actualización: 2026-06-23
> Autor: Doria (SENA ADSO #3413974) | Equipo: Análisis y Desarrollo de Software

## Contenido

Agrupa backlog técnico, riesgos, dependencias y preguntas abiertas del proyecto.

## Archivos

| Archivo | Descripción | Estado |
|---------|-------------|--------|
| [risks.md](./risks.md) | Riesgos documentados en SRS (pérdida de datos, internet inestable, resistencia tecnológica, etc.); mitigación | 🟢 |
| [dependencies.md](./dependencies.md) | Dependencias internas y externas | 🔴 |
| [technical-backlog.md](./technical-backlog.md) | Pendientes técnicos y deuda documentada | 🔴 |
| [open-questions.md](./open-questions.md) | Preguntas pendientes de decisión o aclaración | 🔴 |
