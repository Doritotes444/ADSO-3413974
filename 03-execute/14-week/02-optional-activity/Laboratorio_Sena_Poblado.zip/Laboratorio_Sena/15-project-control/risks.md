# Riesgos y Mitigación

> **Estado:** 🟢 Estable | **Última actualización:** 2026-06-23

---

## Riesgos Documentados en el SRS

| Código | Riesgo | Origen | Impacto | Probabilidad | Mitigación |
|--------|--------|--------|---------|-----------|-----------|
| **R1** | Pérdida total de registros (incendio/robo) | D01–D06, RNF08 | Crítico | Alta | Respaldo automático en Google Drive + almacenamiento local |
| **R2** | Internet inestable interrumpe operación | Entrevista P11, RNF02 | Alto | Media | Funcionalidad offline completa; sincronización automática al recuperar conexión |
| **R3** | Resistencia tecnológica de operarios | Entrevista P10, RNF01 | Medio | Media | Interfaz intuitiva; inducción máx 2 horas; español colombiano sin tecnicismos |
| **R4** | Precios desactualizados (como ahora) | D04, RNF06 | Medio | Alta | Actualización sin asistencia técnica en ≤3 clics; acceso directo al formulario |
| **R5** | Hardware insuficiente (Android <2 GB RAM) | Entrevista P12, RNF05 | Medio | Baja | Especificación explícita: mínimo 2 GB; compatibilidad probada |
| **R6** | Conflicto de datos offline-online | RNF02, Secc. 7.3 | Medio | Media | Last-write-wins; notificación al admin si hay anomalía |
| **R7** | Cartera de crédito sin seguimiento | D02, RF05 | Medio | Alta | Módulo dedicado con alertas de morosidad; historial de abonos trazable |

---

## Plan de Mitigación Activo

| Riesgo | Acción Preventiva | Frecuencia | Responsable |
|--------|------------------|-----------|-----------|
| R1 | Prueba mensual de recuperación de backup | Mensual | Admin / DevOps |
| R2 | Pruebas de sincronización offline en staging | Cada sprint | QA |
| R3 | Sesión de capacitación con operarios | Antes del go-live | Soporte |
| R4 | Validación de actualización de precios en UAT | Antes del go-live | Carlos Ruiz |
| R5 | Pruebas en tablet Android 8.0 con 2 GB RAM | Antes del go-live | QA |
| R6 | Monitoreo de logs de sincronización | Diario (post-go-live) | Operaciones |
| R7 | Auditoría de créditos vencidos | Mensual | Carlos Ruiz |

---

**Control de proyecto:** [dependencies.md](./dependencies.md) | [open-questions.md](./open-questions.md)
